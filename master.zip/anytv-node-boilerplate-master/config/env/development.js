'use strict';

module.exports = {
    ENV : 'development'
};
