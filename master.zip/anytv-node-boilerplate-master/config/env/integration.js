'use strict';

module.exports = {
    ENV : 'integration'
};
