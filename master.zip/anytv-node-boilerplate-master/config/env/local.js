'use strict';

module.exports = {
    ENV : 'local'
};
