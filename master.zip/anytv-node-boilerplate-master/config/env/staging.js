'use strict';

module.exports = {
    ENV : 'staging'
};
