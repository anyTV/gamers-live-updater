'use strict';

module.exports = {
    ENV : 'test'
};
