INSERT INTO users VALUES (
    'cf9fcb1f-8fea-499a-b58f-c69576a11cd5',
    '2014-01-01 00:00:00',
    NULL
);
